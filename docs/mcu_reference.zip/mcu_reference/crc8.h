#ifndef SEASKY_CRC8_H
#define SEASKY_CRC8_H

#include <stdbool.h>
#include <stddef.h>  /* NULL */
#include <stdint.h>

#define CRC_START_8 0x00

uint8_t crc_8(const uint8_t *input_str, uint16_t num_bytes);
uint8_t update_crc_8(uint8_t crc, uint8_t val);

#endif
